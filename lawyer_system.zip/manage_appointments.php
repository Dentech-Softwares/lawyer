<?php
require_once 'db.php';
require_once 'includes/helpers.php';
$pendingAppointmentsCount = getRow("SELECT COUNT(*) as count FROM appointments WHERE status = 'pending' AND is_read = 0")["count"] ?? 0;
// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Get filter values
$statusFilter = $_GET['status'] ?? '';
$dateFilter = $_GET['date'] ?? '';
$caseTypeFilter = $_GET['case_type'] ?? '';

// Build query
$sql = "SELECT a.*, u.name as client_name, u.email as client_email, u.phone as client_phone, a.is_read 
        FROM appointments a 
        JOIN users u ON a.user_id = u.id 
        WHERE 1=1";

$params = [];

if ($statusFilter) {
    $sql .= " AND a.status = ?";
    $params[] = $statusFilter;
}

if ($dateFilter) {
    $sql .= " AND a.date = ?";
    $params[] = $dateFilter;
}

if ($caseTypeFilter) {
    $sql .= " AND a.case_type = ?";
    $params[] = $caseTypeFilter;
}

$sql .= " ORDER BY a.created_at DESC";

$appointments = getAllRows($sql, $params);

// Get unique case types for filter
$caseTypes = getAllRows("SELECT DISTINCT case_type FROM appointments ORDER BY case_type");

// Admin header data
    $admin_username = $_SESSION['admin_username'];
    $admin_email = $_SESSION['admin_email'] ?? '';
    $admin_phone = $_SESSION['admin_phone'] ?? '';
    $current_date = date('F j, Y');

// Count of flagged continuations for the sidebar badge
$continuationBadgeCount = getRow("SELECT COUNT(*) as count FROM appointments WHERE is_continuation = 1 AND status != 'completed' AND is_read = 0")["count"] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments - Justice Law Firm</title>
    <link rel="stylesheet" href="fontawesome-free-7.3.1-web/css/all.min.css">
    <link rel="stylesheet" href="assets/css/sidebar.css">
    <link rel="stylesheet" href="assets/css/table-mobile.css">
    <link rel="stylesheet" href="assets/css/status-badges.css">
    <link rel="stylesheet" href="assets/css/page-transition.css">
    <style>
        :root {
            --primary: #1a3a5c;
            --secondary: #2c5282;
            --accent: #d4af37;
            --accent-hover: #b8962e;
            --white: #ffffff;
            --light-gray: #f5f7fa;
            --dark: #1a202c;
            --gray: #718096;
            --success: #38a169;
            --danger: #e53e3e;
            --warning: #d69e2e;
            --info: #3182ce;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-gray);
            color: var(--dark);
        }

        /* Main Content Area is styled by assets/css/sidebar.css */

        .header-actions {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .logout-btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.8rem 1.5rem;
            background: var(--danger);
            color: var(--white);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: #c53030;
        }

        /* Filters */
        .filters {
            background: var(--white);
            padding: 1.5rem;
            border-radius: 10px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .filters h3 {
            color: var(--primary);
            margin-bottom: 1rem;
            font-size: 1.1rem;
        }

        .filter-form {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .filter-form select,
        .filter-form input {
            padding: 0.8rem 1rem;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 0.95rem;
            min-width: 150px;
        }

        .filter-form select:focus,
        .filter-form input:focus {
            outline: none;
            border-color: var(--accent);
        }

        .btn {
            padding: 0.7rem 1.5rem;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            font-size: 0.95rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }

        .btn-primary {
            background: var(--accent);
            color: var(--primary);
        }

        .btn-primary:hover {
            background: var(--accent-hover);
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--light-gray);
            color: var(--gray);
        }

        .btn-outline:hover {
            border-color: var(--accent);
            color: var(--accent);
        }

        /* Table */
        .section-card {
            background: var(--white);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .table-container {
            overflow-x: auto;
        }

        table.appointments-table {
            width: 100%;
            border-collapse: collapse;
        }

        table.appointments-table th,
        table.appointments-table td {
            padding: 1rem 1.5rem;
            text-align: left;
        }

        table.appointments-table th {
            background: var(--light-gray);
            color: var(--primary);
            font-weight: 600;
            font-size: 0.9rem;
        }

        table.appointments-table td {
            border-bottom: 1px solid var(--light-gray);
            color: var(--dark);
        }

        table.appointments-table tr.appointment-row {
            cursor: pointer;
            transition: background 0.2s ease;
        }

        table.appointments-table tr.appointment-row:hover {
            background: var(--light-gray);
        }

        table.appointments-table tr.appointment-row:active {
            background: #e8eef5;
        }

        /* Highlight unread rows (the shared rule in assets/css/table-mobile.css
           keeps this gold highlight on top of the zebra striping) */
        table.appointments-table tr.unread {
            background-color: #fff9e6;
            border-left: 4px solid #ffc107;
        }

        /* Status pills come from assets/css/status-badges.css so they match
           the badges on the Continuations table in admin_schedule.php */

        .action-buttons {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .btn-icon {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 0.85rem;
            text-decoration: none;
        }

        .btn-icon i {
            color: inherit;
        }

        .btn-approve {
            background: rgba(56, 161, 105, 0.1);
            color: var(--success);
        }

        .btn-approve:hover {
            background: var(--success);
            color: var(--white);
        }

        .btn-reject {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }

        .btn-reject:hover {
            background: var(--danger);
            color: var(--white);
        }

        .btn-complete {
            background: rgba(49, 130, 206, 0.1);
            color: var(--info);
        }

        .btn-complete:hover {
            background: var(--info);
            color: var(--white);
        }

        .btn-delete {
            background: rgba(229, 62, 62, 0.1);
            color: var(--danger);
        }

        .btn-delete:hover {
            background: var(--danger);
            color: var(--white);
        }

        .btn-view {
            background: var(--light-gray);
            color: var(--primary);
        }

        .btn-view:hover {
            background: var(--primary);
            color: var(--white);
        }

        .message-cell {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: help;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 1rem;
        }

        /* Mobile Menu Button */

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

        }

        @media (max-width: 768px) {

            .filter-form {
                flex-direction: column;
            }

            .filter-form select,
            .filter-form input {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php
    $sidebar_role = 'admin';
    $sidebar_badges = [
        'appointments' => $pendingAppointmentsCount,
        'schedule' => $continuationBadgeCount,
    ];
    include 'includes/sidebar.php';
    ?>

    <!-- Main Content -->
    <main class="main-content">
        <?php include 'admin_header.php'; ?>

        <!-- Filters -->
        <div class="filters">
            <h3><i class="fas fa-filter"></i> Filter Appointments</h3>
            <form class="filter-form" method="GET" action="">
                <select name="status">
                    <option value="">All Status</option>
                    <option value="pending" <?php echo $statusFilter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="approved" <?php echo $statusFilter == 'approved' ? 'selected' : ''; ?>>Approved</option>
                    <option value="rejected" <?php echo $statusFilter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    <option value="completed" <?php echo $statusFilter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                </select>
                
                <select name="case_type">
                    <option value="">All Case Types</option>
                    <?php foreach($caseTypes as $ct): ?>
                        <option value="<?php echo $ct['case_type']; ?>" <?php echo $caseTypeFilter == $ct['case_type'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($ct['case_type']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <input type="date" name="date" value="<?php echo $dateFilter; ?>" placeholder="Filter by date">
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Filter
                </button>
                
                <a href="manage_appointments.php" class="btn btn-outline">
                    <i class="fas fa-times"></i> Clear
                </a>
            </form>
        </div>

        <!-- Appointments Table -->
        <div class="section-card">
            <div class="table-container table-responsive">
                <?php if(!empty($appointments)): ?>
                    <table class="appointments-table table">
                        <thead>
                                <tr>
                                    <th>Case #</th>
                                    <th>Client Info</th>
                                    <th>Case Type</th>
                                    <th>Date & Time</th>
                                    <th>Status</th>
                                    <th>Continuation</th>
                                </tr>
                        </thead>
                        <tbody>
                            <?php foreach($appointments as $apt): ?>
                                <tr class="appointment-row <?php echo $apt['is_read'] == 0 ? 'unread' : ''; ?>" onclick="window.location.href='appointment_details.php?id=<?php echo $apt['id']; ?>'">
                                                <td>#<?php echo $apt['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($apt['client_name']); ?></strong><br>
                                        <small><?php echo htmlspecialchars($apt['client_email']); ?></small><br>
                                        <small><?php echo htmlspecialchars($apt['client_phone']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($apt['case_type']); ?></td>
                                    <td>
                                        <?php echo date('M d, Y', strtotime($apt['date'])); ?><br>
                                        <small><?php echo date('h:i A', strtotime($apt['time'])); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge badge-status badge-<?php echo strtolower($apt['status']); ?>">
                                           <?php echo ucfirst($apt['status']); ?>
                                       </span>
                                    </td>
                                    <td style="text-align: center;">
                                        <?php if ($apt['is_continuation']): ?>
                                            <span class="status-badge" style="background: rgba(212, 175, 55, 0.15); color: var(--accent); border: 1px solid var(--accent);">
                                                Yes
                                            </span>
                                        <?php else: ?>
                                            <span class="status-badge" style="background: rgba(212, 175, 55, 0.15); color: var(--accent); border: 1px solid var(--accent);">
                                                No
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <h3>No Appointments Found</h3>
                        <p>No appointments match your filter criteria</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }
    </script>
    <script src="assets/js/auto-update.js"></script>
</body>
</html>
